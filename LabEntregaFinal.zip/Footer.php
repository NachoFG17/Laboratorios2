<footer>
    <p>Trabajo realizado por: Pascual Freitas, Juan Bentancor, Mateo Vairo, Yeremy Schanzenbach y Hermán García</p>
</footer>

</body>
</html>