<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos.css">
    <title>Document</title>
</head>
<body>

    <header>
        <nav class="navegador">
       
         <ul class="contenedoropciones">
            <li class="opciones"> <a href="factoriales.php">Calculadora Factorial</a></li>
            <li class="opciones"><a href="tablas.php">Tablas de Multiplicar</a></li>
            <li class="opciones"><a href="5deoro.php">Probabilidad 5 de oro</a></li>
        </ul>

        </nav>
        
    </header>